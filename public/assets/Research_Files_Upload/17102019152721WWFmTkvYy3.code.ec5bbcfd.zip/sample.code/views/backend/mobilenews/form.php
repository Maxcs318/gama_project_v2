<div class="row" >
	<div class="col-sm-12 col-md-12 main" >

		<div class="row">
			<div class="col-md-12">
				<div class="header">
					<h3 class="text-muted">
						<?php echo "จัดการข่าวบนมือถือ" ?>
					</h3>
				</div>
			</div>
		</div>

		<hr />

		<div style="height: 20px;"></div>

		<div class="row">
			<div class="col-md-12">
				<form class="form-horizontal" id="frm_news_mobile" name="frm_news_mobile" role="form" action="?" method="post" enctype="multipart/form-data" >
					<?php $news_mobile_id = !empty($news) ? $news->news_mobile_id  :  0 ;  ?>
					<input type="hidden" name="news_mobile_id" value="<?php echo $news_mobile_id  ?>" /> 
					<?php $news_mobile_title = !empty($news) ? $news->news_mobile_title : "" ;  ?>
					<div class="form-group">
						<label for="article_title" class="col-sm-2 control-label">หัวเรือง</label>
						<div class="col-sm-9">
							<input type="text" class="form-control" 
								id="news_mobile_title" name="news_mobile_title" value="<?php echo htmlspecialchars($news_mobile_title)?>"
								placeholder="" required="required" >
						</div>
					</div>
					 <div class="form-group">
						<label for="article_title" class="col-sm-2 control-label">รายละเอียด</label>
						<div class="col-sm-9">
							<?php $news_mobile_detail = !empty($news) ? $news->news_mobile_detail : "" ;  ?>
							 <textarea id="news_mobile_detail" name="news_mobile_detail" rows="5" cols="" class="form-control"><?php 
							 	echo htmlspecialchars($news_mobile_detail) ;
							 ?></textarea>
						</div>
					</div>
					
					<div class="form-group">
						<label class="col-sm-2 control-label" for="news_mobile_images">
							รูปภาพสินค้า
						</label>
						<?php $news_mobile_images = !empty($news) ? $news->news_mobile_images : "" ;  ?>
						<div class="col-sm-10">
							<?php if(!empty($news_mobile_images)){ ?>
							<img style="display:block;" src="<?php echo site_url("public/uploads/contents/" . $news_mobile_images ) ?>" class="img-thumbnail" id="imgProductImage">
							<?php } ?>
							<div data-provides="fileinput" class="fileinput fileinput-new">
								<span class="btn btn-default btn-file">
									<span class="fileinput-new">Select file</span>
									<span class="fileinput-exists">Change</span>
									<input type="file" name="news_mobile_images" id="news_mobile_images" kl_virtual_keyboard_secure_input="on">
								</span>
								<span class="fileinput-filename"></span>
								<a style="float: none" data-dismiss="fileinput" class="close fileinput-exists" href="#">×</a>
							</div>
						</div>
					</div>
					
					<div class="form-group">
						<div class="col-sm-offset-2 col-sm-9">
							<div class="checkbox">
								<?php $is_show = !empty($news) ? $news->is_show : 1 ;  ?>
								<label> <input type="checkbox" id=""is_show"" name="is_show" value="1" <?php echo $is_show == 1 ? "checked" : "" ;  ?> > แสดงข้อมูล 
								</label>
							</div>
						</div>
					</div>
					
					<div class="form-group">
						<div class="col-sm-offset-3 col-sm-9">
							<button type="submit" class="btn btn-primary">บันทึกข้อมูล</button>
							<a href="#" class="btn btn-default">ออกจากการบันทึก</a>
						</div>
					</div>
				</form>
			</div>
		</div>

	</div> <!-- /.main -->
</div> 