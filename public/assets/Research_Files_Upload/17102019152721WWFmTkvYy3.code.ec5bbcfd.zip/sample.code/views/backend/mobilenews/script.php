<script src="<?php echo site_url("public/assets/ckeditor/ckeditor.js")?>" ></script>
<script>
	$(function(){
		 CKEDITOR.replace( "news_mobile_detail" , {customConfig: '/public/assets/ckeditor/config-ver-2.js'} );
		  
		 
	})
</script>