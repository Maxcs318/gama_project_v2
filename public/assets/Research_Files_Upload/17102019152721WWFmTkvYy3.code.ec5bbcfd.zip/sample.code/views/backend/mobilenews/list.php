<div class="row" >
	<div class="col-sm-12 col-md-12 main" >
	 
		<div class="row">
			<div class="col-md-12">
				<div class="header">
					<ul class="nav nav-pills pull-right">
						<li class="active">
							<a href="<?php echo site_url("backend/mobilenews/form")?>" id="btnAdd" href="">
								<i class="fa fa-plus"></i> เพิ่มข้อมูล
							</a>
						</li>
					</ul>
					<h3 class="text-muted"> <?php echo "จัดการข่าวบนมือถือ" ?></h3>
				</div>
			</div>
		</div>
		<hr/>
		
		<div style="height:20px;"></div>
		
		<div class="row">
			<div class="col-md-12 table-responsive">
			<?php echo $table ?>
			<!--   ="table table-hover">
				<thead>
					<tr>
						<th>#</th>
						<th>หัวเรือง</th>
						<th>จัดการ</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>1</td>
						<td>"โรคคิดลบ"โรคติดต่อชนิดหนึ่ง</td>
						<td>
							<a href="#" class="update">แก้ไข</a> | 
							<a href="#" class="delete" onclick="return confirm('ต้องการลบข้อมูลนี้?')">ลบ</a>
						</td>
					</tr>
					<tr>
						<td>2</td>
						<td>"โรคคิดลบ"โรคติดต่อชนิดหนึ่ง</td>
						<td>
							<a href="#" class="update">แก้ไข</a> | 
							<a href="#" class="delete" onclick="return confirm('ต้องการลบข้อมูลนี้?')">ลบ</a>
						</td>
					</tr>
				</tbody>
			</table>
			-->
			
			</div>
		</div>
		
  			
			 
			
	</div> <!-- /.main -->
</div> 