<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

require 'BackendController.php';

class Mobilenews extends BackendController {
 
	public function index($offset = 0 )
	{
		$this->load->library('pagination');
		$this->load->library('table');
		$this->load->model("news_mobile_model" , "news_mobile_model") ;
		$config = get_pagination_config() ;
		$uri_segment = 4;
		$per_page = 10 ;
		$offset = $this->uri->segment($uri_segment);
			
		$news = $this->news_mobile_model->order_by("createdate" , "desc")->limit($per_page , $offset )->get_all();
		
		$config["base_url"] = site_url('backend/mobilenews/index/');
		$config["total_rows"] = $this->news_mobile_model->count_all();
		$config["per_page"] = $per_page ;
		
		$config["uri_segment"] = $uri_segment;
		$this->pagination->initialize($config);
		$data['pagination'] = $this->pagination->create_links();
			
		// generate table data
		$tmpl = array ( 'table_open'  => '<table class="table table-hover">' );
		$this->table->set_template($tmpl);
		$this->table->set_empty("&nbsp;");
		$this->table->set_heading("#" , "วันที่แสดง" , "หัวเรือง"   , "จัดการ" );
		$i = 0 + $offset;
		foreach ($news as $row){
			$this->table->add_row(++$i
					, date("d-m-Y",strtotime($row->createdate))
					, $row->news_mobile_title
					, anchor("backend/mobilenews/form/" . $row->news_mobile_id,'แก้ไข',array('class'=>'update')).' | '.
					anchor("backend/mobilenews/delete/"  .$row->news_mobile_id ,'ลบ',array('class'=>'delete','onclick'=>"return confirm('ต้องการลบข้อมูลนี้?')"))
			);
		}
		
		$message = $this->session->flashdata("messagebox") ;
		$type = $this->session->flashdata("messagetype") ;
		
		$data["meesagebox"] = get_alert_box_html($message , $type) ;
		$data["table"] =  $this->table->generate();
		$data["content_title"] = "จัดการข่าวมือถือ" ;
		
		$data["url_form_add"] =  site_url("backend/mobilenews/form");
	 
		$this->get_header("backend/mobilenews/header" , array($data )) ;	
		$this->load->view('backend/mobilenews/list' , $data );
		$this->get_footer("backend/mobilenews/script" , array()) ;
	}
	
	public function form($news_mobile_id = 0 )
	{
		$this->load->model("news_mobile_model" , "news_mobile_model") ;
   		// $this->load->model("article_category_model","article_category_model");
   		//$this->load->model("article_notification_model","article_notification_model");
   		//$this->load->model("notification_model","notification_model");
   		
   		 
   		
   		if ($this->input->server("REQUEST_METHOD") === "POST"){
   			$article = array();
   			$news_mobile_id = intval($this->input->post("news_mobile_id")) ; 
    			
   			$news["news_mobile_title"] = $this->input->post("news_mobile_title");
   			$news["news_mobile_detail"] = $this->input->post("news_mobile_detail");
   			$news["news_mobile_count"] = "0" ;  
   			$news_mobile_images = "" ; 
   			if(!empty($_FILES["news_mobile_images"])) {
   				$ints = date("YmdGis") . random_char(7);
   				if($_FILES["news_mobile_images"]["type"]=="image/png"||$_FILES["news_mobile_images"]["type"]=="image/x-png")
   					$imgsn = $ints.".png";
   				if($_FILES["news_mobile_images"]["type"]=="image/gif")
   					$imgsn = $ints.".gif";
   				elseif($_FILES["news_mobile_images"]["type"]=="image/pjpeg"||$_FILES["news_mobile_images"]["type"]=="image/jpeg")
   				$imgsn = $ints.".jpg";
   				if(!empty($imgsn)) {
   					$path = "/public/uploads/contents/{$imgsn}" ;
   					@copy( $_FILES["news_mobile_images"]["tmp_name"] ,$_SERVER["DOCUMENT_ROOT"] . $path );
   					$news_mobile_images = "{$imgsn}"  ;
    			}
   			}
   			$news["news_mobile_images"] = $news_mobile_images ; 
   			$news["is_show"] = intval($this->input->post("is_show") , 0) ; 
    		$news["updatedate"] = date("Y-m-d H:i:s");
    			
   			if( $news_mobile_id == 0 ){
   				
   				$news["createdate"] = $news["updatedate"] ;
   				$insert_id = $this->news_mobile_model->insert($news);
   				
     		}else{
   				$this->news_mobile_model->update( $news_mobile_id , $news);
   				
   			}
   			
   			$this->session->set_flashdata("messagebox", "ได้ทำการบันทึกข้อมูลแล้ว");
   			$this->session->set_flashdata("messagetype", "success");
   			redirect("backend/mobilenews/index") ; 
   			return true ;
   		}
   		
   		
   		$data = array();
   		$data["content_title"] = "จัดการข่าวประชาสัมพันธ" ;
   		$data["back_to_list_url"] = site_url("backend/article/index") ;
   		
   		$news = $this->news_mobile_model->get($news_mobile_id);
    
   		$data["news"] = $news ; 
   		
     	
		$this->get_header("backend/mobilenews/header" , array(   )) ;
		$this->load->view('backend/mobilenews/form' , $data );
		$this->get_footer("backend/mobilenews/script" , array()) ;
	}
	
	public function delete($news_mobile_id = 0 ){
		
		$this->load->model("news_mobile_model" , "news_mobile_model") ;
		$this->news_mobile_model->delete($news_mobile_id);
		
		$this->session->set_flashdata("messagebox", "ได้ทำลบข้อมูลแล้ว");
		$this->session->set_flashdata("messagetype", "warning");
		redirect("backend/mobilenews/index") ;
		return true ;
	}
}
 