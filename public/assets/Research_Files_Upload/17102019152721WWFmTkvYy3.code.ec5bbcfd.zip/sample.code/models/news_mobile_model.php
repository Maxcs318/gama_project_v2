<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class News_Mobile_Model extends MY_Model {
	public $primary_key  = 'news_mobile_id' ;
	public $_table = 'ept_news_mobile' ;


} 